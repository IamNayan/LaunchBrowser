//it will launch browser before every test case
package tests.setup;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;

import libs.common.Utils;

public class Setup {
	
	@Parameters({"dataFile","driverPath", "appUrl", "pageLoadTimeout","screenshots"})
	@BeforeSuite 
	public void init(String dataFile,String driverPath , String appUrl,String pageLoadTimeout,String screenshots) //execute onlu once before class,before start of exectuon
	{
		Utils.setTestDataFile(dataFile); //I am excpecting this files from testng.xml
		Utils.LaunchBrowser(driverPath, appUrl, Integer.parseInt(pageLoadTimeout));
		Utils.setTestScreenshotFile(screenshots);
		Utils.sleep(3000);
		
	}
}

