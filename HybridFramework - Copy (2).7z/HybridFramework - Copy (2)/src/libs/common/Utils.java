package libs.common;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Utils {

	private static WebDriver driver;
	private static String dataFile;
	private static String screenshotsFile;

	//package lib
	public static void sleep(int millSec)
	{
		try {
			Thread.sleep(millSec);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void LaunchBrowser(String driverPath, String appUrl,int pageLoadTimeout) {	

		System.setProperty("webdriver.chrome.driver", driverPath);
		driver = new ChromeDriver();
		//driver.get(appUrl); //Caller will pass-"http://localhost:8999/hawtio/welcome"
		
		/*List<String> appUrl1 = Utils.getTestData("ApplicationUrl");
		for(String app : appUrl1)	{	
		 driver.get(app); 
		}*/
		
		List<String> appUrll = Utils.getTestData("ApplicationUrl");			
		driver.get(appUrll.get(0));

		//browser loading time out and maximizing 	
		driver.manage().timeouts().pageLoadTimeout(pageLoadTimeout,TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	//In case if any class /object needs access to driver object
	public static WebDriver getDriver()
	{
		return driver;
	}

	public static void setTestDataFile(String filePath)
	{
		dataFile = filePath;

	}
	
	public static void setTestScreenshotFile(String screenshotsFilePath)
	{
		screenshotsFile = screenshotsFilePath;

	}

	public static List<String> getTestData(String TestName){
		List<String> testData = new ArrayList<String>();
		try {
			XSSFWorkbook book = new XSSFWorkbook(dataFile);//which workbook I want to read
			XSSFSheet sheet1 = book.getSheet("Sheet1"); //

			//Iterate over Excel
			for(Row row : sheet1)
			{
				Cell cell0 = row.getCell(0);
				String cell0Data = cell0.getStringCellValue();				

				if(cell0Data.equals(TestName)){					
					for(Cell cell : row)
					{						
						String data = cell.getStringCellValue();
						testData.add(data);
						//System.out.println(data);
					}
					break;
				}					
			}

			book.close();
			testData.remove(0);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return testData;			
		//TestName = i/p=Test3 o/p=will be peter NewYork Enginerr
	}
	
	public static void captureScreenshot(String fileName){		
		try{
		
		TakesScreenshot sc = (TakesScreenshot)driver;
		File file = sc.getScreenshotAs(OutputType.FILE);
		File destFile = new File(screenshotsFile + "/"+fileName);
		FileUtils.copyFile(file, destFile); //memory to physical file
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}

}
