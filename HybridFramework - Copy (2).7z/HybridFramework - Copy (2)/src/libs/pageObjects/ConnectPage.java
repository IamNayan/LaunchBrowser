package libs.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ConnectPage {
	
	
	WebElement name; 
	//name ,id and varaible name is same in your java file you dont have to mention @FindBy annotaion as well
	//selenium will automaticlly will do it for you
	WebElement host;
	public void setName(String nameToSet)
	{
		name.sendKeys(nameToSet);		
	}
	
	public void setHost(String hostToSet)
	{
		host.sendKeys(hostToSet);
	}
	
	@FindBy(xpath="//input[@class='login-email']")
	WebElement username;	
	public void setUser(String userNameToSet)
	{
		username.sendKeys(userNameToSet);
		
	}
	
	@FindBy(xpath="//input[@class='login-password']")
	WebElement pass;	
	public void setUserPass(String passToSet)
	{
		pass.sendKeys(passToSet);
	}

}
