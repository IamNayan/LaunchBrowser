package libs.pageObjects;

import org.openqa.selenium.WebElement;

public class ConnectPage {
	
	
	WebElement name; 
	//name ,id and varaible name is same in your java file you dont have to mention @FindBy annotaion as well
	//selenium will automaticlly will do it for you
	WebElement host;
	public void setName(String nameToSet)
	{
		name.sendKeys(nameToSet);		
	}
	
	public void setHost(String hostToSet)
	{
		host.sendKeys(hostToSet);
	}

}
