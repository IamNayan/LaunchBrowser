package libs.pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class WelcomePage {
	
	@FindBy(linkText="Connect")
	WebElement connectLink;
	
	@FindBy(linkText= "Wiki")
	WebElement wikiLink;
	
	public void clickConnect()
	{
		connectLink.click();		
	}
	
	public void clickWiki()
	{
		wikiLink.click();		
	}

}
