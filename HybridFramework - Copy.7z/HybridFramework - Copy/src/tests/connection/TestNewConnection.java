package tests.connection;

import static org.testng.Assert.assertEquals;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import libs.common.Utils;
import libs.pageObjects.ConnectPage;
import libs.pageObjects.WelcomePage;

public class TestNewConnection {
	
	@Test
	public void createConnection(){
		WelcomePage welcomePg = PageFactory.initElements(Utils.getDriver(), WelcomePage.class);
		welcomePg.clickConnect();
		
		 //ConnectPage enterName = PageFactory.initElements
		//ConnectPage enterName = new ConnctPage we are not using this as if we initialize this with new
	     //it will send null to instance variable-it will throw NUllPointer Exception
		
		ConnectPage enterName = PageFactory.initElements(Utils.getDriver(), ConnectPage.class);
		List<String> data = Utils.getTestData("Test1");//reading test data from excel
		
		enterName.setName(data.get(0));//passing to function
		
		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		
		Utils.captureScreenshot("ConnectPage"+timeStamp+".jpg");
		
		/*String expectedStr = "Tom";
		String actualStr = "tom";
		try{
		Assert.assertTrue(expectedStr.equals(actualStr),"String are not matching");
		}
		catch(AssertionError err){
			err.printStackTrace();
		}*/
		
		//Assertion without try catch is hard Assertion
		//Assertion with try catch is soft Assertion
		//Assert.assertEquals
		//Assert.Assert.assertFalse
		//Assert.Null
		
		ConnectPage enterHost = PageFactory.initElements(Utils.getDriver(), ConnectPage.class);
		enterHost.setHost("25");
		
		
	}
}
